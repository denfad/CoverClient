package ru.denfad.cover.network;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;
import ru.denfad.cover.models.Place;

/*
Interface that describes methods of interaction with a server
* */
public interface JSONPlaceHolderNetwork {

    //Returns all places in DB
    @GET("/places/")
    public Call<List<Place>> getPlaces();
    // Returns the place on a specific coordinates
    @POST("/places/")
    public Call<Place> getPlace(@Query("x") double x, @Query("y") double y);
}
